-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 05, 2024 at 08:11 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petadoption`
--

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

DROP TABLE IF EXISTS `inquiries`;
CREATE TABLE IF NOT EXISTS `inquiries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `preference` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `inquiries`
--

INSERT INTO `inquiries` (`id`, `name`, `email`, `preference`, `submitted_at`) VALUES
(6, 'Jasvir kaur', 'jaskaur@gmail.com', '', '2024-12-05 07:56:56'),
(7, 'Jasvir kaur', 'jaskaur@gmail.com', '', '2024-12-05 07:57:21'),
(8, 'Jasvir kaur', 'jaskaur@gmail.com', '', '2024-12-05 07:58:17'),
(9, 'sunil thakur', 'sunil@gmail.com', 'dfvfv', '2024-12-05 07:58:41'),
(10, 'sunil thakur', 'sunil@gmail.com', 'dfvfv', '2024-12-05 07:59:09'),
(11, 'sunil thakur', 'sunil12@gmail.com', 'hello sunil', '2024-12-05 08:00:09'),
(12, 'sunil thakur', 'sunil12@gmail.com', 'hello sunil', '2024-12-05 08:01:31'),
(13, 'Jasvir kaur', 'jaskaur@gmail.com', 'hye dear', '2024-12-05 08:03:31'),
(14, 'bhawan', 'bal@gnail.com', 'vhhkbj', '2024-12-05 08:04:22'),
(15, 'Radha', 'radha@gmail.com', 'saxksakx', '2024-12-05 08:05:56'),
(16, 'Radha', 'radha@gmail.com', 'saxksakx', '2024-12-05 08:06:21'),
(17, 'Radha', 'radha1@gmail.com', 'hello', '2024-12-05 08:06:39'),
(18, 'Sunil Jasvir', 'suja@gmail.com', 'hello sunil jasvir', '2024-12-05 08:08:12');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
