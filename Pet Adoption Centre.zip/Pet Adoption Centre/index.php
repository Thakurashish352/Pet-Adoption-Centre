
<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Update with your database password
$dbname = "petadoption"; // Update with your database name

// Establish connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve and sanitize input data
    $name = $conn->real_escape_string($_POST["name"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $preference = $conn->real_escape_string($_POST["preference"]);

    // SQL query to insert data into the Inquiries table
    $sql = "INSERT INTO Inquiries (name, email, preference) 
            VALUES ('$name', '$email', '$preference')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "Thank you, $name. Your adoption inquiry has been received. We'll contact you at $email.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>Pet Adoption Centre</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Welcome to the Pet Adoption Centre</h1>
        <nav>
            <a href="#home">Home</a>
            <a href="#available-pets">Available Pets</a>
            <a href="#calculator">Care Cost Calculator</a>
            <a href="#contact">Contact Us</a>
        </nav>
    </header>

    <!-- Home Page -->
    <section id="home">
        <h2 align="center">Home</h2>
        
		<section id="available-pets">  
    <div id="pets-container">
        <div class="pet-card">
            <img src="image/1.jpg" alt="Max the dog">
            <h3>havenese</h3>
            
            <p>Age: 3 years</p>
        </div>
        <div class="pet-card">
            <img src="image/bela.jpg" alt="Whiskers the cat">
            <h3>Cavalier</h3>
            
            <p>Age: 2 years</p>
        </div>
        <div class="pet-card">
            <img src="image/peacock.jpg" alt="Polly the parrot">
            <h3>Polly</h3>
            
            <p>Age: 1 year</p>
        </div>
    </div>
</section>
    </section>

    <!-- Available Pets Page -->
    <section id="available-pets">
        <h2>Available Pets</h2>
        <p>Browse through our list of adorable pets waiting for their forever home.</p>
        <div id="pets-container">
	<!--dog Section-->
           <section id="available-pets">
    <h2>Dogs</h2>
   
    <div id="pets-container">
        <div class="pet-card">
            <img src="image/1.jpg" alt="Max the dog">
            <h3>havenese</h3>
            
            <p>Age: 3 years</p>
        </div>
        <div class="pet-card">
            <img src="image/CavalierKingCharles.jpeg" alt="Whiskers the cat">
            <h3>Cavalier</h3>
            
            <p>Age: 2 years</p>
        </div>
        <div class="pet-card">
            <img src="image/pug.jpg" alt="Polly the parrot">
            <h3>Polly</h3>
            
            <p>Age: 1 year</p>
        </div>
    </div>
</section>
<!--Cat Section-->
<section id="available-pets">
    <h2>Cat</h2>
  
    <div id="pets-container">
        <div class="pet-card">
            <img src="image/bela.jpg" alt="Max the dog">
            <h3>Bella</h3>
            
            <p>Age: 3 years</p>
        </div>
        <div class="pet-card">
            <img src="image/Callie.jpg" alt="Whiskers the cat">
            <h3>Cavalier</h3>
            
            <p>Age: 2 years</p>
        </div>
        <div class="pet-card">
            <img src="image/Chloe.jpg" alt="Polly the parrot">
            <h3>Polly</h3>
            
            <p>Age: 1 year</p>
        </div>
    </div>
</section>
<!--Bird Section-->
<section id="available-pets">
    <h2>Birds</h2>
    
    <div id="pets-container">
        <div class="pet-card">
            <img src="image/parrot.jpg" alt="Max the dog">
            <h3>Parrot</h3>
            
            <p>Age: 3 years</p>
        </div>
        <div class="pet-card">
            <img src="image/peacock.jpg" alt="Whiskers the cat">
            <h3>Peacock</h3>
            
            <p>Age: 2 years</p>
        </div>
        <div class="pet-card">
            <img src="image/spirit.jpg" alt="Polly the parrot">
            <h3>Spirit</h3>
           
            <p>Age: 1 year</p>
        </div>
    </div>
</section>
        </div>
    </section>

    <!-- Care Cost Calculator Page -->
    <section id="calculator">
        <h2>Care Cost Calculator</h2>
        <p>Estimate the daily care cost for your potential pet adoption:</p>
        <form id="cost-calculator">
            <label for="pet-type">Select Pet Type:</label>
            <select id="pet-type" name="pet-type">
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
                <option value="bird">Bird</option>
            </select>
            <label for="days">Number of Days:</label>
            <input type="number" id="days" name="days" min="1" required>
            <button type="button" onclick="calculateCost()">Calculate</button>
        </form>
        <p id="result"></p>
    </section>

    <!-- Contact Us Page -->
    <section id="contact">
        <h2>Contact Us</h2>
        <p>Submit your adoption inquiry below, and we'll get in touch with you soon:</p>
        <form action="" method="POST">
            <label for="name">Your Name:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="text" id="name" name="name" required><br />
            <label for="email">Email:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="email" id="email" name="email" required><br />
            <label for="pet-preference">Pet Preference:</label>
            <textarea id="pet-preference" name="preference" rows="4"></textarea><br />
            <button type="submit">Submit</button>
        </form>
    </section>

    <footer>
        <p>Pet Adoption Centre</p>
    </footer>

    <script src="script.js"></script>
	
</body>
</html>
