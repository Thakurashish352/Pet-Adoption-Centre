function calculateCost() {
    const petType = document.getElementById("pet-type").value;
    const days = parseInt(document.getElementById("days").value, 10);
    let dailyCost;

    switch (petType) {
        case "dog":
            dailyCost = 10;
            break;
        case "cat":
            dailyCost = 8;
            break;
        case "bird":
            dailyCost = 5;
            break;
        default:
            dailyCost = 0;
    }

    const totalCost = dailyCost * days;
    document.getElementById("result").textContent = `Estimated Care Cost: $${totalCost}`;
}
